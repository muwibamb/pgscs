#include <iostream>
#include "../inc/gauge.h"
using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#define BUFSIZER1 512
#define BUFSIZER2 ((BUFSIZER1/2) - 8)

int main(int argc, char *argv[]) 
{
  
  ConfigurationFile conf("gauges.conf");

  Gauge frequency = Gauge(conf, "Frequency");
  Gauge rpm = Gauge(conf, "RPM");

  frequency.makeSVG("html/gauges/frequency.svg");

  rpm.makeSVG("html/gauges/rpm.svg");
  

  return 0;
}